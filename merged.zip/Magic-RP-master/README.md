# Magic-RP

The source assets and build tools used in the various official Magic resource packs
